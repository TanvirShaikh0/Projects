import pickle
import numpy as np
import requests
import json

READ_API_KEY = 'WIY3UJCMGK7PJI1M'
CHANNEL_ID = 2374213

# Load the model and scalers
model = pickle.load(open('model.pkl', 'rb'))
sc = pickle.load(open('standscaler.pkl', 'rb'))
ms = pickle.load(open('minmaxscaler.pkl', 'rb'))

# Define the crop dictionary
crop_dict = {1: "Rice", 2: "Maize", 3: "Jute", 4: "Cotton", 5: "Coconut", 6: "Papaya", 7: "Orange",
             8: "Apple", 9: "Muskmelon", 10: "Watermelon", 11: "Grapes", 12: "Mango", 13: "Banana",
             14: "Pomegranate", 15: "Lentil", 16: "Blackgram", 17: "Mungbean", 18: "Mothbeans",
             19: "Pigeonpeas", 20: "Kidneybeans", 21: "Chickpea", 22: "Coffee"}

url = f'https://api.thingspeak.com/channels/{CHANNEL_ID}/feeds.json?api_key={READ_API_KEY}'

# Send the GET request and capture the response
response = requests.get(url)

# Convert the response to JSON
data = json.loads(response.text)

# Check if there are any entries
if 'feeds' in data and len(data['feeds']) > 0:
    # Extract the latest entry
    entry = data['feeds'][-1]

    # Extract and print the sensor data
    print(f"Entry ID: {entry['entry_id']}")
    print(f"Nitrogen: {entry['field1']}")
    print(f"Phosphorous: {entry['field2']}")
    print(f"Potassium: {entry['field3']}")
    print(f"Humidity: {entry['field4']}")
    print(f"Temperature: {entry['field5']}")
    print(f"pH: {entry['field6']}")
    print("-------------------------")
else:
    print("No entries found.")


def predict_crop(nitrogen, phosphorous, potassium, humidity, temperature, ph, rainfall):
    # Create a numpy array with the input data
    input_data = np.array([[nitrogen, phosphorous, potassium, humidity, temperature, ph, rainfall]])

    # Use the saved scalers to preprocess the input data
    input_data_scaled = sc.transform(input_data)
    input_data_scaled_minmax = ms.transform(input_data_scaled)

    # Make the prediction using the model
    prediction = model.predict(input_data_scaled_minmax)

    # Map the prediction to the corresponding crop name
    predicted_crop = crop_dict.get(prediction[0], "Unknown Crop")

    return predicted_crop

# Example usage
predicted_crop = predict_crop(entry['field1'], entry['field2'], entry['field3'], entry['field4'], entry['field5'], entry['field6'], 100)
print("Predicted Crop:", predicted_crop)
