import pickle
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import numpy as np

# Sample training data (features and target)
X_train = np.random.rand(100, 7)  # 100 samples, 7 features
y_train = np.random.randint(1, 23, 100)  # 100 samples, target in range 1 to 22

# Standardize and normalize the training data
sc = StandardScaler()
ms = MinMaxScaler()
X_train_scaled = sc.fit_transform(X_train)
X_train_scaled_minmax = ms.fit_transform(X_train_scaled)

# Train a DecisionTreeClassifier
model = DecisionTreeClassifier()
model.fit(X_train_scaled_minmax, y_train)

# Save the model and scalers
with open('model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)
with open('standscaler.pkl', 'wb') as scaler_file:
    pickle.dump(sc, scaler_file)
with open('minmaxscaler.pkl', 'wb') as minmax_file:
    pickle.dump(ms, minmax_file)
