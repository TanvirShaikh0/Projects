import pickle
import numpy as np
import gradio as gr
import requests
import json

from pac_data.data_se import predicted_crop, main_data

READ_API_KEY = 'WIY3UJCMGK7PJI1M'
CHANNEL_ID = 2374213

# Load the model and scalers
model = pickle.load(open('model.pkl', 'rb'))
sc = pickle.load(open('standscaler.pkl', 'rb'))
ms = pickle.load(open('minmaxscaler.pkl', 'rb'))

# Define the crop dictionary
crop_dict = {
    1: "Rice", 2: "Maize", 3: "Jute", 4: "Cotton", 5: "Coconut", 6: "Papaya", 7: "Orange",
    8: "Apple", 9: "Muskmelon", 10: "Watermelon", 11: "Grapes", 12: "Mango", 13: "Banana",
    14: "Pomegranate", 15: "Lentil", 16: "Blackgram", 17: "Mungbean", 18: "Mothbeans",
    19: "Pigeonpeas", 20: "Kidneybeans", 21: "Chickpea", 22: "Coffee"
}

url = f'https://api.thingspeak.com/channels/{CHANNEL_ID}/feeds.json?api_key={READ_API_KEY}'

# Send the GET request and capture the response
response = requests.get(url)
data = response.json()
entry = data['feeds'][-1]

# Extract and print the sensor data
print(f"Entry ID: {entry['entry_id']}")

d1 = int(entry['field1'])
d2 = int(entry['field2'])
d3 = int(entry['field3'])
d4 = float(entry['field4'])
d5 = float(entry['field5'])
d6 = float(entry['field6'])

# Check if 'main_data' contains any value
print("Output of main_data():", main_data)

# Assign the value of 'predicted_crop' to the textbox
initial_predicted_crop = str(predicted_crop)

# Gradio interface components
def predic_crop(nitrogen, phosphorous, potassium, humidity, temperature, ph, rainfall):
    # Create a numpy array with the input data
    input_data = np.array([[nitrogen, phosphorous, potassium, humidity, temperature, ph, rainfall]])

    # Use the saved scalers to preprocess the input data
    input_data_scaled = sc.transform(input_data)
    input_data_scaled_minmax = ms.transform(input_data_scaled)

    # Make the prediction using the model
    prediction = model.predict(input_data_scaled_minmax)

    # Map the prediction to the corresponding crop name
    predicted_crop = crop_dict.get(prediction[0], "Unknown Crop")
    return predicted_crop

# Gradio interface
inputs = [
    gr.Number(label="Nitrogen", value=d1),
    gr.Number(label="Phosphorous", value=d2),
    gr.Number(label="Potassium", value=d3),
    gr.Number(label="Humidity", value=d4),
    gr.Number(label="Temperature", value=d5),
    gr.Number(label="pH", value=d6),
    gr.Number(label="Rainfall", value=20)
]

outputs = gr.Textbox(label="Predicted Crop", value=initial_predicted_crop)

# Custom CSS for background image
css = """
body {
    background-image: url('Default.jpg');
    background-size: cover;
    background-repeat: no-repeat;
}
"""

def app():
    return gr.Interface(fn=predic_crop, inputs=inputs, outputs=outputs, title="Crop Prediction App", css=css)

# Launch the app
if __name__ == "__main__":
    simple_app = app()
    simple_app.launch()
