import requests

def get_rainfall_data(api_key, city):
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        'q': city,
        'appid': api_key,
        'units': 'metric'  # Use 'imperial' for Fahrenheit
    }

    try:
        response = requests.get(base_url, params=params)
        data = response.json()

        if response.status_code == 200:
            rainfall = data.get('rain', {}).get('1h', 0)
            print(f"Rainfall in {city}: {rainfall} cm")
        else:
            print(f"Error: {data['message']}")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # Replace 'YOUR_API_KEY' with your actual OpenWeatherMap API key
    api_key = '4986107e3673e10e16649a67807ab2be'
    city = 'London'  # Replace with the desired city

    get_rainfall_data(api_key, city)
