package EnzigmaTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ForgetPassword {
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login");
		
		driver.findElement(By.linkText("Forgot Password?")).click();
		
		WebElement email = driver.findElement(By.xpath("//section[@role='dialog']//input"));
		
		WebElement proceed = driver.findElement(By.xpath("//div[text()='Proceed']"));
		
		
//		CLICKING PROCEED WITHOUT ENTERING ANYTHING IN EMAIL FIELD
		
		proceed.click();
		
		WebElement error_msg = driver.findElement(By.xpath("//h2[text()='Please enter email']"));
		
		System.out.println("Is Email Field Is Mandatory ==> "+error_msg.isDisplayed());
		System.out.println();
		
		 WebElement close = driver.findElement(By.xpath("//div[@class='slds-notify__close']"));
		close.click();
		
		Thread.sleep(3000);
		
		
		
//		VALIDATING THE DIFFERENT FORMATS FOR THE EMAIL FIELD
		
		 String[][] testData = {
                 {"examplegmail.com", "Invalid"},      // Missing @ symbol
                 {"example@", "Invalid"},              // Missing domain
                 {"@gmail.com", "Invalid"},            // Missing username
                 {"exa<>mple@gmail.com", "Invalid"},   // Invalid characters
                 {"plainaddress", "Invalid"},         // No @ or domain
                 {".username@yahoo.com", "Invalid"},  // Starts with a dot
                 {"user@.com", "Invalid"},            // Domain starts with a dot
                 {"user@domain..com", "Invalid"},      // Double dot in domain
                 {"user.name+tag/gmail.com", "Invalid"}, // Invalid with special characters
                 {"#user@domain.co.in", "Invalid"},       // Invalid subdomain email
                 {"hilaw15712@nalwan.com", "Valid"}        // Valid email - placed last as page changes
             };

         for (String[] data : testData) 
         {
             String email_ = data[0];
             String expectedResult = data[1];
             
             WebElement emailField = driver.findElement(By.xpath("//section[@role='dialog']//input"));
             WebElement proceedbutton = driver.findElement(By.xpath("//div[text()='Proceed']"));

             // Input email and click proceed
             
             emailField.clear();
             emailField.sendKeys(email_);
             
             proceedbutton.click();
             
             Thread.sleep(2000);
//             close.click();
             
             String actualResult = null;
             try 
             {
                 WebElement errorMessage = driver.findElement(By.xpath("//h2[text()='Please enter email']"));
                 WebElement success = driver.findElement(By.xpath("//h2[text()='Verification code sent successfully']"));
                 
                 if (errorMessage.isDisplayed()) 
                 {
                     actualResult = "Invalid";
                 }
                 else 
                 {
                     actualResult = "Valid";
                 }
             } 
             catch (Exception e) 
             {
                 actualResult = "Valid"; // Assume valid if no error message is displayed
             }
             
             if (actualResult.equals(expectedResult)) {
                 System.out.println("Test Passed for email: " + email_);
                               
 
             } 
             else 
             {
                 System.out.println("Test Failed for email: " + email_);
             }
             
             // Break loop if last valid email is reached
             if (expectedResult.equals("Valid") && email.equals("hilaw15712@nalwan.com")) {
                 System.out.println("Final valid email encountered, stopping further tests.");
                 break;
             }
             
             System.out.println();
             System.out.println("Verificaation code sent successfull");        
             
         }
	}
}
