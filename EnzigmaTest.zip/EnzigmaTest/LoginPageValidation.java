package EnzigmaTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class LoginPageValidation {

	public static void main(String[] args) throws InterruptedException {
		
		String expected_url = "https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login";
		
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://app-staging.nokodr.com/");
		
		String actual_url = driver.getCurrentUrl();
		
		if(expected_url.equals(actual_url))
		{
			System.out.println(" i am in nokodr website");
			
//			KEEPING THE EMAIL FIELD BLANK AND ONLY SENDING THE PASSWORD IN PASSWORD FIELD AND CLICKING LOGIN
			
			WebElement emailField = driver.findElement(By.xpath("//input[@type='email']"));
			WebElement passField = driver.findElement(By.xpath("//input[@type='password']"));
			passField.sendKeys("1234567890");
			WebElement loginField = driver.findElement(By.xpath("//div[text()='Log In']"));
			loginField.click();
			
//			CHECKING IF EMAIL IS MANDATORY OR NOT USING isDisplayed();
			
			WebElement email_mandatory = driver.findElement(By.xpath("//h2[text()='Please enter email']"));
			System.out.println("Is email mandatory field for login ==> "+email_mandatory.isDisplayed());
			Thread.sleep(2000);
			passField.clear();
			Thread.sleep(2000);
			
//			KEEPING THE  PASSWORD FIELD BLANK AND ONLY SENDING THE EMAIL IN EMAIL FIELD AND CLICKING LOGIN
			
			emailField.sendKeys("VEER@GMAIL.COM");
			loginField.click();
			
//			CHECKING IF PASSWORD IS MANDATORY OR NOT BY USING isDisplayed();
			
			WebElement pass_mandatory = driver.findElement(By.xpath("//h2[@class='slds-text-heading_small']"));
			System.out.println("Is password mandatory field for login ==> "+pass_mandatory.isDisplayed());
			
			Thread.sleep(3000);
			emailField.clear();
			
//          FINDING THE VALID EMAIL FORMAT 
            
          String[][] testData = {
                  {"examplegmail.com", "Invalid"},      // Missing @ symbol
                  {"example@", "Invalid"},              // Missing domain
                  {"@gmail.com", "Invalid"},            // Missing username
                  {"exa<>mple@gmail.com", "Invalid"},   // Invalid characters
                  {"plainaddress", "Invalid"},         // No @ or domain
                  {".username@yahoo.com", "Invalid"},  // Starts with a dot
                  {"user@.com", "Invalid"},            // Domain starts with a dot
                  {"user@domain..com", "Invalid"},      // Double dot in domain
                  {"user.name+tag/gmail.com", "Invalid"}, // Invalid with special characters
                  {"#user@domain.co.in", "Invalid"},       // Invalid subdomain email
                  {"hilaw15712@nalwan.com", "Valid"}        // Valid email - placed last as page changes
              };

          for (String[] data : testData) 
          {
              String email = data[0];
              String expectedResult = data[1];
              
              WebElement emailField1 = driver.findElement(By.xpath("//input[@type='email']"));
              WebElement passField1 = driver.findElement(By.xpath("//input[@type='password']"));
              WebElement loginButton1 = driver.findElement(By.xpath("//div[text()='Log In']"));

              // Input email and click submit
              emailField1.clear();
              passField1.clear();
              emailField1.sendKeys(email);
              passField1.sendKeys("Beer@123");
              
              Thread.sleep(2000);
              loginButton1.click();
              
              Thread.sleep(2000);
              
              String actualResult;
              try 
              {
                  WebElement errorMessage = driver.findElement(By.xpath("//h2[@class='slds-text-heading_small']"));
                  if (errorMessage.isDisplayed()) 
                  {
                      actualResult = "Invalid";
                  } 
                  else 
                  {
                      actualResult = "Valid";
                  }
              } 
              catch (Exception e) 
              {
                  actualResult = "Valid"; // Assume valid if no error message is displayed
              }
              
              if (actualResult.equals(expectedResult)) {
                  System.out.println("Test Passed for email: " + email);
                  
              } 
              else 
              {
                  System.out.println("Test Failed for email: " + email);
              }
              
              // Break loop if last valid email is reached
              if (expectedResult.equals("Valid") && email.equals("hilaw15712@nalwan.com")) {
                  System.out.println("Final valid email encountered, stopping further tests.");
                  break;
              }
          }    
			System.out.println("successfully logined");
		}
		else
		{
			System.out.println(" i am not in nokodr website");
		}
		
		
	}
}

    
