package EnzigmaTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BasicScript {
	
	public static void main(String[] args) {
		
		String expected_url = "https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login";
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://app-staging.nokodr.com/");
		
		String actual_url = driver.getCurrentUrl();
		
		if(expected_url.equals(actual_url))
		{
			System.out.println("I am in NOKODR website");
		}
		else
		{
			System.out.println("I am not in NOKODR website");
		}
		
	}

}
