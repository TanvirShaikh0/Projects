package EnzigmaTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Sign_Up {

    public static WebDriver driver;

    public static void main(String[] args) {
        try {
            // Initialize WebDriver and navigate to the website
            initializeDriver();

            // Expected URL to validate
            String expected_url = "https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login";

            // Get the actual URL of the page
            String actual_url = driver.getCurrentUrl();

            if (expected_url.equals(actual_url)) {
                System.out.println("I am in Nokodr website");

                // Perform sign-up actions
                performSignUp();

                // Test email field validation
                testEmailValidation();

                // Finalize and close the test
                finalizeTest();
                
        		
//        		------------------------------HERE WE REQUIRED OTP TO TO VALIDAE THE EMAIL-----------------------
//        		-----------------------------WHICH IS NOT POSSIBLE, SO AS IT WAS(OPTIONAL)-----------------------
//        		-------------------------------------SO OTP SECTION IS SKIPPED-----------------------------------
        		
                
                
                WebElement register = driver.findElement(By.xpath("//div[text()='Register']"));
        		WebElement fname = driver.findElement(By.xpath("//input[@name='firstName']"));
        		WebElement lname = driver.findElement(By.xpath("//input[@name='lastName']"));
        		WebElement pass = driver.findElement(By.xpath("//section[@role='dialog']//input[@name='password']"));
        		WebElement conf_pass = driver.findElement(By.xpath("//section[@role='dialog']//input[@name='password-confirmpassword']"));
        		
//        		NOW WITHOUT ENTERING FNAME AND GIVING GIVINNG INPUT IN LNAME
        		
        		lname.sendKeys("beer");
        		pass.sendKeys("Veer@123");
        		conf_pass.sendKeys("Veer@123");
        		
        		
        		if(register.isEnabled())
        		{
        			System.out.println("First Name is a mandatory field");
        		}
        		else
        		{
        			System.out.println("First Name is not a mandatory field");
        		}
        		
        		
//        		NOW ENTERING FNAME AND REMOVING LNAME
        		
        		fname.sendKeys("Veer");
        		lname.clear();
        		
        		if(register.isEnabled())
        		{
        			System.out.println("Last Name is a mandatory field");
        		}
        		else
        		{
        			System.out.println("Last Name is not a mandatory field");
        		}
        		
//        		NOW ENTERING LNAME AND REMOVING PASSWORD
        		
        		lname.sendKeys("Beer");
        		pass.clear();
        		
        		if(register.isEnabled())
        		{
        			System.out.println("Password is a mandatory field");
        		}
        		else
        		{
        			System.out.println("Password is not a mandatory field");
        		}
        		
//        		NOW ENTERING PASSWORD AND REMMOVING CONFIRM PASSWORD

        		pass.sendKeys("Veer@123");
        		conf_pass.clear();
        		
        		if(register.isEnabled())
        		{
        			System.out.println("Confirm Password is a mandatory field");
        		}
        		else
        		{
        			System.out.println("Confirm Password is not a mandatory field");
        		}
        		

        		 // Input Test Data  
                String[] firstNameInvalid = {"", "123", "!!@#", "John Doe", "A B"};  
                String validFirstName = "John";  

                String[] lastNameInvalid = {"", "123", "!!@#", "John Doe", "B C"};  
                String validLastName = "Doe";  

                String[] passwordInvalid = {"", "12345", "password", "pass123", "abcde"};  
                String validPassword = "Secure@123";  

                String[] confirmPasswordInvalid = {"", "12345", "password", "pass123", "abcde"};  
                String validConfirmPassword = validPassword;  

                // Test invalid first names  
                for (String firstName : firstNameInvalid) {  
                    performSignUp(driver, firstName, validLastName, validPassword, validConfirmPassword);  
                }  

                // Test invalid last names  
                for (String lastName : lastNameInvalid) {  
                    performSignUp(driver, validFirstName, lastName, validPassword, validConfirmPassword);  
                }  

                // Test invalid passwords  
                for (String password : passwordInvalid) {  
                    performSignUp(driver, validFirstName, validLastName, password, validConfirmPassword);  
                }  

                // Test invalid confirm passwords  
                for (String confirmPassword : confirmPasswordInvalid) {  
                    performSignUp(driver, validFirstName, validLastName, validPassword, confirmPassword);  
                }  

                // Valid inputs  
                performSignUp(driver, validFirstName, validLastName, validPassword, validConfirmPassword);
                
                
                driver.quit();
                
                
                
            } else 
            {
                System.out.println("I am not in Nokodr website");
            }

            // Close the WebDriver
            closeDriver();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("An error occurred during the execution.");
        }
    }

    // Initialize WebDriver and maximize the window
    public static void initializeDriver() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://app-staging.nokodr.com/");
    }

    // Perform the sign-up process
    public static void performSignUp() throws InterruptedException {
        driver.findElement(By.linkText("Sign up")).click();

        // Click on the submit button without entering an email
        driver.findElement(By.xpath("//abx-button[@label='Proceed']")).click();
        Thread.sleep(1000);

        // Check if email is a mandatory field
        WebElement email_error_Message = driver.findElement(By.xpath("//h2[text()='Please enter email']"));
        System.out.println("Is email mandatory ==> " + email_error_Message.isDisplayed());

        Thread.sleep(2000);

        // Enter a valid email in the email field
        driver.findElement(By.xpath("//section[@role='dialog']//input")).sendKeys("veer@gmail.com");
        Thread.sleep(4000);

        // Click on the submit button without clicking "I Agree"
        driver.findElement(By.xpath("//abx-button[@label='Proceed']")).click();

        // Check if the "I Agree" checkbox is mandatory
        WebElement agree_con_message = driver.findElement(By.xpath("//h2[@class='slds-text-heading_small']"));
        System.out.println("Is 'I agree' button mandatory ==> " + agree_con_message.isDisplayed());
    }

    // Test the email validation for different formats
    public static void testEmailValidation() throws InterruptedException {
        String[][] testData = {
            {"examplegmail.com", "Invalid"},
            {"example@", "Invalid"},
            {"@gmail.com", "Invalid"},
            {"exa<>mple@gmail.com", "Invalid"},
            {"plainaddress", "Invalid"},
            {".username@yahoo.com", "Invalid"},
            {"user@.com", "Invalid"},
            {"user@domain..com", "Invalid"},
            {"user.name+tag/gmail.com", "Valid"},
            {"#user@domain.co.in", "Valid"},
            {"example@gmail.com", "Valid"}
        };

        // Locate the email field, agree checkbox, and submit button
        WebElement emailField = driver.findElement(By.xpath("//section[@role='dialog']//input"));
        WebElement agreeField = driver.findElement(By.xpath("//label[@class='slds-checkbox__label']"));
        WebElement submitButton = driver.findElement(By.xpath("//abx-button[@label='Proceed']"));

        for (String[] data : testData) {
            String email = data[0];
            String expectedResult = data[1];

            // Input the email and click submit
            emailField.clear();
            emailField.sendKeys(email);
            agreeField.click();
            submitButton.click();

            Thread.sleep(4000);

            // Validate the result of the email
            validateEmailResult(expectedResult, email);

            // Stop after the last valid email
            if (expectedResult.equals("Valid") && email.equals("example@gmail.com")) {
                System.out.println("Final valid email encountered, stopping further tests.");
                break;
            }
        }
    }

    // Validate the email result by checking error messages
    public static void validateEmailResult(String expectedResult, String email) {
        try {
            WebElement errorMessage = driver.findElement(By.xpath("//h2[@class='slds-text-heading_small']"));
            if (errorMessage.isDisplayed()) {
                System.out.println("Test Failed for email: " + email);
            } else {
                System.out.println("Test Passed for email: " + email);
            }
        } catch (Exception e) {
            System.out.println("Test Passed for email: " + email);
        }
    }

    // Finalize the test
    public static void finalizeTest() throws InterruptedException {
        Thread.sleep(5000); // Wait for any additional actions
    }

    // Close the WebDriver
    public static void closeDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
    
    
    public static void performSignUp(WebDriver driver, String firstName, String lastName, String password, String confirmPassword) throws InterruptedException {  
        WebElement firstNameField = driver.findElement(By.xpath("//input[@name='firstName']"));  
        WebElement lastNameField = driver.findElement(By.xpath("//input[@name='lastName']"));  
        WebElement passwordField = driver.findElement(By.xpath("//section[@role='dialog']//input[@name='password']"));  
        WebElement confirmPasswordField = driver.findElement(By.xpath("//section[@role='dialog']//input[@name='password-confirmpassword']"));  
        WebElement submitButton = driver.findElement(By.xpath("//div[text()='Register']"));  

        // Enter values  
        firstNameField.clear();  
        firstNameField.sendKeys(firstName);  

//        Thread.sleep(2000);
        lastNameField.clear();  
        lastNameField.sendKeys(lastName);  

//        Thread.sleep(2000);
        passwordField.clear();  
        passwordField.sendKeys(password);  
//        Thread.sleep(2000);

        confirmPasswordField.clear();
        confirmPasswordField.sendKeys(confirmPassword);  

        // Check if the submit button is enabled  
        if (submitButton.isEnabled()) {  
            
        	System.out.println("you have not entered valid details");

        } 
        else 
        {  
            System.out.println("Submit button is enabled. Inputs are valid.");
         // Submit the form  
          submitButton.click(); 
          Thread.sleep(6000);
          String profile_url = "https://app.nokodr.com/super/apps/user-profile/v1/index.html#/";
          
          if(driver.getCurrentUrl().equals(profile_url))
          {
        	  System.out.println("Succeessfully Registered");
          }
          else
          {
        	  System.out.println("Not Registered");
          }
          
        }  
    }  
}
